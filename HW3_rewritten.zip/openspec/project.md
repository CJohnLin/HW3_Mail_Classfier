Project: Rewritten HW3 - spam classification.
