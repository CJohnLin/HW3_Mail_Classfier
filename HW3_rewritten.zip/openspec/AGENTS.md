AGENTS trace: rewrite to reduce similarity.
